# Remember that you'll need to require the sinatra and twitter gems
# You'll then need to include the code to authenticate a Twitter client
