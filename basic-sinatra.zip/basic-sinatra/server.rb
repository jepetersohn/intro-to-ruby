# Put the code for your server in this file.
# Remember that the first line needs to be:
# require 'sinatra'
